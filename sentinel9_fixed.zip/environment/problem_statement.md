The Serilog email sink (`Serilog.Sinks.Email`, root namespace `Serilog`) historically sent mail through `System.Net.Mail` alongside an older MailKit code path selected by compile-time symbols. That dual approach is a maintenance dead end: `System.Net.Mail` is effectively unmaintained for modern SMTP, and the split transport made the sink hard to test and configure. The sink must be modernized to send mail exclusively through MailKit 4.3, with the transport replaceable so the sink's batching and formatting behavior can be exercised without a live SMTP server. This is a breaking migration: consumers must migrate their configuration to MailKit conventions, choosing a `SecureSocketOptions` value and supplying any required credentials explicitly.

The source state you inherit still references `System.Net.Mail` and toggles transports with `SYSTEM_NET`/`MAIL_KIT` conditional-compilation symbols; the target state removes that entirely.

Source state:
- The sink builds against multiple transports selected by build symbols, and the `System.Net.Mail`-based transport is present.
- `EmailSink` constructs its transport internally by calling a factory on `EmailConnectionInfo`, so a batch cannot be emitted without whatever transport the connection info hands back.
- `WriteTo.Email(...)` offers several overloads whose signatures assume a `System.Net.Mail` world and do not require an SMTP host.

Target state and acceptance criteria:

1. When the library is built, it must depend on MailKit 4.3 and must not depend on `System.Net.Mail`; the `SYSTEM_NET`/`MAIL_KIT` conditional transports and the `System.Net.Mail`-based transport are gone, leaving a single MailKit-backed transport.

2. `EmailSink` must accept its transport as a constructor dependency rather than creating one internally. Given an `EmailConnectionInfo`, a body `ITextFormatter`, a subject `ITextFormatter`, and an `IEmailTransport`, constructing the sink must succeed, and the transport must be used for all sends. Passing a null `connectionInfo` or a null `emailTransport` must raise `ArgumentNullException`.

3. Given a sink constructed with a transport, when the sink is disposed the underlying `IEmailTransport` must also be disposed. `IEmailTransport` exposes `Task SendMailAsync(EmailMessage)` and is `IDisposable`. These sink types stay internal, and the assembly's existing `InternalsVisibleTo` grant for the test assembly must remain, so a test project can construct the sink and implement the transport directly.

4. When a batch of log events is emitted, the sink must produce exactly one `EmailMessage` per batch and hand it to the transport's `SendMailAsync`. The message's `Body` is the batch rendered with the supplied body formatter — carrying each event's rendered message and, where present, its exception as the running .NET renders it — its `From` is the configured `FromEmail`, its `To` is the recipient list parsed from `ToEmail`, and `IsBodyHtml` mirrors the connection info.

5. The subject line must be rendered from the most severe event in the batch. Recipients in `ToEmail` must be split on both `,` and `;`, discarding empty entries, so a single address yields a one-element `To` collection.

6. When the supplied body formatter implements `IBatchTextFormatter`, the sink must let it format the entire batch in one pass instead of formatting events individually, so events driven through Serilog's periodic batching coalesce into a single sent email whose body is whatever that formatter produced for the whole batch. Emitting through this path must not write anything to `SelfLog`.

7. `EmailConnectionInfo` must be MailKit-oriented: it exposes `FromEmail`, `ToEmail`, `MailServer`, `Port` (defaulting to `25`), `NetworkCredentials` (`ICredentialsByHost`), `IsBodyHtml` (defaulting to `false`), and a `SecureSocketOption` of MailKit's `SecureSocketOptions` type. Because MailKit provides no XML-based SMTP settings discovery, an SMTP host (`mailServer`) must always be supplied.

8. `WriteTo.Email(...)` must offer two shapes: a configuration-friendly inline overload that takes `fromEmail`, `toEmail`, and a required `mailServer` (plus optional credentials, output template, minimum level, batching controls, format provider, and subject) and throws `ArgumentNullException` when `loggerConfiguration`, `fromEmail`, `toEmail`, or `mailServer` is null; and an overload that accepts a complete `EmailConnectionInfo` on its own, with optional caller-supplied body/subject formatters and batching options, throwing `ArgumentNullException` when the connection info is null.

Observable behavior for a correct implementation: emitting a batch results in a single well-formed `EmailMessage` delivered to the injected transport with the body, subject, sender, recipients, and HTML flag described above; disposing the sink tears down the transport; and batch-aware formatters control the whole-batch rendering. The repository's existing test project is part of this migration: it currently builds against the old constructor and the removed transport factory, so it must be carried over to the new API and keep passing. The graded harness is a separate test project supplied by the grader.
