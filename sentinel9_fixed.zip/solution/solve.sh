#!/usr/bin/env bash
set -euo pipefail
cd /app

PATCH=/solution/golden.patch

if git apply -p1 --check --whitespace=nowarn "$PATCH" 2>/dev/null; then
  git apply -p1 --whitespace=nowarn "$PATCH"
# The reverse probe has to come before the 3-way one: `git apply --3way` implies
# `--index`, so even its `--check` form disturbs the index enough to make a
# following reverse probe report a false negative on an already-solved tree.
elif git apply -p1 -R --check --whitespace=nowarn "$PATCH" 2>/dev/null; then
  # The patch reverses cleanly, which is only true of a tree that already carries
  # the solution. Leave it untouched so re-running stays an idempotent no-op, and
  # never reverse it.
  echo "golden.patch is already applied; leaving the solved tree unchanged" >&2
elif git apply -p1 --3way --check --whitespace=nowarn "$PATCH" 2>/dev/null; then
  git apply -p1 --3way --whitespace=nowarn "$PATCH"
else
  # Neither direction applies: the tree is in neither the base nor the solved
  # state, so the oracle cannot establish the solution. Fail loudly rather than
  # reporting success on an unsolved tree.
  echo "ERROR: /solution/golden.patch does not apply to /app, and does not reverse out of it either." >&2
  echo "The working tree is in neither the expected base state nor the solved state; refusing to continue." >&2
  exit 1
fi
