#!/usr/bin/env bash
set -e
cd /app
if git apply -p1 --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --whitespace=nowarn /solution/golden.patch
elif git apply -p1 --3way --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --3way --whitespace=nowarn /solution/golden.patch
else
  # The patch does not apply forward — the tree is already solved. Leave it
  # untouched so re-running is an idempotent no-op (never reverse the solution).
  echo "golden.patch already applied; leaving the solved tree unchanged" >&2
fi
