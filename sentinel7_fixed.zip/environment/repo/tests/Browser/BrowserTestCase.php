<?php

namespace Tests\Browser;

use Closure;
use Facebook\WebDriver\Exception\ElementClickInterceptedException;
use Facebook\WebDriver\Exception\ElementNotInteractableException;
use Facebook\WebDriver\Exception\ElementNotVisibleException;
use Facebook\WebDriver\Exception\NoSuchElementException;
use Facebook\WebDriver\Exception\StaleElementReferenceException;
use Facebook\WebDriver\WebDriverBy;
use Illuminate\Config\Repository;
use Illuminate\Http\Request;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\View\Factory;
use Laravel\Dusk\Browser;
use Livewire\LivewireServiceProvider;
use Orchestra\Testbench\Dusk\Options;
use Orchestra\Testbench\Dusk\TestCase;
use TallStackUi\Facades\TallStackUi;
use TallStackUi\Http\AsyncUpload\Uploader;
use TallStackUi\TallStackUiServiceProvider;

use function Livewire\trigger;

class BrowserTestCase extends TestCase
{
    public static function tmp(): string
    {
        return __DIR__.'/tmp/';
    }

    public static function tweakApplicationHook(): Closure
    {
        return function () {};
    }

    protected function clean(): void
    {
        Artisan::call('view:clear');

        app()->forgetInstance('livewire.factory');

        RateLimiter::clear('livewire-checksum-failures:127.0.0.1');

        File::deleteDirectory(self::tmp());
        File::deleteDirectory($this->livewireViewsPath());
        File::deleteDirectory($this->livewireClassesPath());
        File::deleteDirectory($this->livewireTestsPath());
        File::delete(app()->bootstrapPath('cache/livewire-components.php'));

        File::ensureDirectoryExists(self::tmp());
    }

    protected function defineEnvironment($app): void
    {
        tap($app['session'], function ($session) {
            $session->put('_token', str()->random(40));
        });

        tap($app['config'], function (Repository $config) {
            $config->set('app.env', 'testing');
            $config->set('app.debug', true);
            $config->set('view.paths', [__DIR__.'/views', resource_path('views')]);
            $config->set('app.key', 'base64:Hupx3yAySikrM2/edkZQNQHslgDWYfiBfCuSThJ5SK8=');
            $config->set('database.default', 'testbench');
            $config->set('database.connections.testbench', [
                'driver' => 'sqlite',
                'database' => ':memory:',
                'prefix' => '',
            ]);
            $config->set('filesystems.disks.tmp-for-tests', [
                'driver' => 'local',
                'root' => self::tmp(),
            ]);
            $config->set('cache.default', 'array');
        });

        tap($app['view'], function (Factory $factory) {
            $factory->addNamespace('layouts', __DIR__.'/views/layouts');
            $factory->addNamespace('pages', __DIR__.'/views/pages');
        });
    }

    /** @param Router $router */
    protected function defineWebRoutes($router): void
    {
        $router->post('/async-upload', function (Request $request) {
            $controller = new class
            {
                use Uploader;

                public function store(Request $request)
                {
                    return $this->upload($request, ['directory' => 'browser-uploads']);
                }
            };

            return $controller->store($request);
        })->name('async.upload');

        $router->post('/async-upload-strict', function (Request $request) {
            $controller = new class
            {
                use Uploader;

                public function store(Request $request)
                {
                    return $this->upload($request, [
                        'directory' => 'browser-uploads',
                        'rules' => ['file' => ['mimes:png']],
                    ]);
                }
            };

            return $controller->store($request);
        })->name('async.upload.strict');

        $router->get('/searchable-simple', fn () => [
            [
                'label' => 'delectus aut autem',
                'value' => 'delectus aut autem',
            ],
            [
                'label' => 'quis ut nam facilis et officia qui',
                'value' => 'quis ut nam facilis et officia qui',
            ],
            [
                'label' => 'fugiat veniam minus',
                'value' => 'fugiat veniam minus',
            ],
            [
                'label' => 'et porro tempora',
                'value' => 'et porro tempora',
            ],
            [
                'label' => 'laboriosam mollitia et enim quasi adipisci quia provident illum',
                'value' => 'laboriosam mollitia et enim quasi adipisci quia provident illum',
            ],
        ])->name('searchable.simple');

        $router->get('/searchable-filtered', function (Request $request) {
            $options = collect([
                [
                    'label' => 'delectus aut autem',
                    'value' => 'delectus aut autem',
                ],
                [
                    'label' => 'quis ut nam facilis et officia qui',
                    'value' => 'quis ut nam facilis et officia qui',
                ],
                [
                    'label' => 'fugiat veniam minus',
                    'value' => 'fugiat veniam minus',
                ],
                [
                    'label' => 'et porro tempora',
                    'value' => 'et porro tempora',
                ],
                [
                    'label' => 'laboriosam mollitia et enim quasi adipisci quia provident illum',
                    'value' => 'laboriosam mollitia et enim quasi adipisci quia provident illum',
                ],
            ]);

            if (! $request->has('search')) {
                return $options;
            }

            return [
                [
                    'label' => 'et porro tempora',
                    'value' => 'et porro tempora',
                ],
            ];
        })->name('searchable.filtered');

        $router->get('/tab-navigation-target', fn () => '<html><head></head><body>Tab Navigation Target Page</body></html>');

        $router->post('/mock-command-palette-action', fn () => response()->json([
            'type' => 'event',
            'data' => ['name' => 'action-executed', 'params' => ['source' => 'actionable']],
            'external' => false,
        ]));

        $router->get('/command-palette-redirect-target', fn () => '<html><head></head><body>Redirect Target</body></html>');

        $router->match(['get', 'post'], '/searchable-by-category', function (Request $request) {
            $category = $request->input('category', 'none');

            return match ($category) {
                'A' => [
                    ['label' => 'Alpha One', 'value' => 'alpha-1'],
                    ['label' => 'Alpha Two', 'value' => 'alpha-2'],
                ],
                'B' => [
                    ['label' => 'Beta One', 'value' => 'beta-1'],
                    ['label' => 'Beta Two', 'value' => 'beta-2'],
                ],
                default => [
                    ['label' => 'Default Item', 'value' => 'default'],
                ],
            };
        })->name('searchable.by-category');

        $router->get('/searchable-with-metadata', fn () => [
            ['value' => 'Alice', 'description' => 'admin', 'metadata' => ['id' => 42, 'role' => 'admin']],
            ['value' => 'Bob', 'description' => 'editor'],
        ])->name('searchable.with-metadata');
    }

    protected function getApplicationTimezone($app): string
    {
        return (bool) getenv('GITHUB_ACTIONS') === false ? 'America/Sao_Paulo' : $app['config']['app.timezone'];
    }

    protected function getPackageAliases($app): array
    {
        return ['TallStackUi' => TallStackUi::class];
    }

    protected function getPackageProviders($app): array
    {
        return [
            LivewireServiceProvider::class,
            TallStackUiServiceProvider::class,
        ];
    }

    protected function livewireClassesPath($path = ''): string
    {
        return app_path('Livewire'.($path ? '/'.$path : ''));
    }

    protected function livewireTestsPath($path = ''): string
    {
        return base_path('tests/Feature/Livewire'.($path ? '/'.$path : ''));
    }

    protected function livewireViewsPath($path = ''): string
    {
        return resource_path('views').'/livewire'.($path ? '/'.$path : '');
    }

    /**
     * clickAtVisibleXPath() covers clickAtXPath(), which drives the raw driver
     * without waiting or retrying, so a click landing on a region that Alpine
     * is still rendering fails outright. waitForAllText() waits for every
     * entry of a list, where waitForText() resolves as soon as one is visible.
     */
    protected function macros(): void
    {
        Browser::macro('clickAtVisibleXPath', function (string $expression, ?int $seconds = null) {
            $by = WebDriverBy::xpath($expression);

            $this->driver->wait($seconds ?? Browser::$waitSeconds)->until(function () use ($by) {
                try {
                    $element = $this->driver->findElement($by);

                    // Enablement is deliberately not part of the condition:
                    // some tests click a disabled element to assert it is inert.
                    if (! $element->isDisplayed()) {
                        return false;
                    }

                    $element->click();

                    return true;
                } catch (NoSuchElementException|StaleElementReferenceException|ElementNotVisibleException|ElementNotInteractableException|ElementClickInterceptedException) {
                    return false;
                }
            }, "Waited for the element at the XPath expression [{$expression}] to become clickable.");

            return $this;
        });

        Browser::macro('waitForAllText', function (array $texts, ?int $seconds = null) {
            foreach ($texts as $text) {
                $this->waitForText($text, $seconds);
            }

            return $this;
        });
    }

    protected function paused(int $seconds = 3): int
    {
        return 1000 * $seconds;
    }

    protected function setUp(): void
    {
        Options::withoutUI();

        $this->macros();

        $this->afterApplicationCreated(fn () => $this->clean());

        $this->beforeApplicationDestroyed(fn () => $this->clean());

        parent::setUp();

        trigger('browser.testCase.setUp', $this);
    }

    protected function skipOnGitHubActions(?string $message = null): void
    {
        if ((bool) getenv('GITHUB_ACTIONS') === false) {
            return;
        }

        $this->markTestSkipped($message ?? 'For some unknown reason this test fails on GitHub Actions.');
    }

    protected function tearDown(): void
    {
        trigger('browser.testCase.tearDown', $this);

        if (! $this->status()->isSuccess()) {
            $this->captureFailuresFor(collect(static::$browsers));
            $this->storeSourceLogsFor(collect(static::$browsers));
        }

        $this->closeAll();

        parent::tearDown();
    }
}
