<?php

return [
    'environment' => [
        'environment' => 'Omgeving',
        'branch' => 'Branch',
    ],

    'errors' => [
        'title' => 'Er zijn :count validatie fouten:',
    ],

    'select' => [
        'default' => 'Kies een optie',
        'search' => 'Zoek hier',
        'empty' => 'Geen resultaten gevonden',
        'selected' => ':count geselecteerd',
    ],

    'autocomplete' => [
        'default' => 'Typ om te zoeken...',
        'empty' => 'Geen resultaten gevonden',
    ],

    'toast' => [
        'button' => [
            'ok' => 'Ok',
            'confirm' => 'Bevestig',
            'cancel' => 'Annuleer',
        ],
    ],

    'dialog' => [
        'button' => [
            'ok' => 'Ok',
            'confirm' => 'Bevestig',
            'cancel' => 'Annuleer',
        ],
    ],

    'command-palette' => [
        'search' => 'Zoeken...',
        'empty' => 'Geen resultaten gevonden.',
        'navigate' => 'navigeren',
        'select' => 'selecteren',
        'close' => 'sluiten',
    ],

    'table' => [
        'empty' => 'Geen resultaten gevonden.',
        'quantity' => 'Aantal',
        'search' => 'Zoek hier',
    ],

    'clipboard' => [
        'button' => [
            'copy' => 'Kopieer',
            'copied' => 'Gekopieerd!',
        ],
    ],

    'password' => [
        'rules' => [
            'title' => 'Verwacht Wachtwoord format:',
            'formats' => [
                'min' => 'Tenminste :min karakters',
                'numbers' => 'Tenminste 1 getal',
                'symbols' => 'Tenminste 1 symbool (:symbols)',
                'mixed' => 'Hoofd- en kleine letters',
            ],
        ],
    ],

    'upload' => [
        'placeholder' => 'Kies een bestand',
        'size' => 'Grootte',
        'upload' => 'Klik hier om op te laden',
        'uploaded' => [
            'single' => ':count bestand verzonden',
            'multiple' => ':count bestanden verzonden',
        ],
        'error' => 'Er ging iets mis. Probeer opnieuw.',
        'static' => [
            'empty' => [
                'title' => 'Geen beelden.',
                'description' => 'Je hebt nog geen enkel beeld.',
            ],
        ],
        'invalid' => 'Er trad een validatiefout op.',
    ],

    'upload_async' => [
        'title' => 'Sleep bestanden hierheen',
        'description' => 'of klik om te selecteren',
        'send' => 'Versturen',
        'clear' => 'Wissen',
        'ready' => [
            'single' => ':count bestand gereed · :size',
            'multiple' => ':count bestanden gereed · :size',
        ],
        'errors' => [
            'mime' => 'Bestandstype niet toegestaan.',
            'size' => 'Het bestand overschrijdt de limiet van :max MB.',
            'limit' => 'Je kunt maximaal :max bestanden opladen.',
            'network' => 'Netwerkfout. Probeer opnieuw.',
            'server' => 'Opladen mislukt. Probeer opnieuw.',
            'integrity' => 'De upload is onvolledig aangekomen. Probeer opnieuw.',
            'unauthorized' => 'Je mag dit bestand niet opladen.',
            'generic' => 'Er ging iets mis.',
        ],
    ],

    'date' => [
        'calendar' => [
            'months' => [
                'january' => 'Januari',
                'february' => 'Februari',
                'march' => 'Maart',
                'april' => 'April',
                'may' => 'Mei',
                'june' => 'Juni',
                'july' => 'Juli',
                'august' => 'Augustus',
                'september' => 'September',
                'october' => 'Oktober',
                'november' => 'November',
                'december' => 'December',
            ],
            'week' => [
                'sunday' => 'Zondag',
                'monday' => 'Maandag',
                'tuesday' => 'Dinsdag',
                'wednesday' => 'Woensdag',
                'thursday' => 'Donderdag',
                'friday' => 'Vrijdag',
                'saturday' => 'Zaterdag',
            ],
        ],
        'helpers' => [
            'yesterday' => 'Gisteren',
            'today' => 'Vandaag',
            'tomorrow' => 'Morgen',
        ],
    ],

    'time' => [
        'helper' => 'Huidige Tijd',
    ],

    'step' => [
        'next' => 'Volgende',
        'previous' => 'Vorige',
        'finish' => 'Voltooien',
    ],

    'key-value' => [
        'headers' => [
            'key' => 'SLEUTEL',
            'value' => 'WAARDE',
        ],
        'placeholders' => [
            'key' => 'Voer een sleutel in',
            'value' => 'Voer een waarde in',
        ],
        'add-row' => 'RIJ TOEVOEGEN',
        'empty' => 'Geen rijen toegevoegd.',
    ],

    'currency' => [
        'symbol' => '€',
        'currency' => 'EUR',
    ],

    'list' => [
        'search' => 'Zoeken',
        'empty' => 'Geen items.',
    ],
];
