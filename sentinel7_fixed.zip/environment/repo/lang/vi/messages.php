<?php

return [
    'environment' => [
        'environment' => 'Môi trường',
        'branch' => 'Nhánh',
    ],

    'errors' => [
        'title' => 'Có :count lỗi xác thực:',
    ],

    'select' => [
        'default' => 'Chọn một tùy chọn',
        'search' => 'Tìm kiếm ở đây',
        'empty' => 'Không tìm thấy kết quả',
        'selected' => ':count đã chọn',
    ],

    'autocomplete' => [
        'default' => 'Nhập để tìm kiếm...',
        'empty' => 'Không tìm thấy kết quả',
    ],

    'toast' => [
        'button' => [
            'ok' => 'Ok',
            'confirm' => 'Xác nhận',
            'cancel' => 'Hủy',
        ],
    ],

    'dialog' => [
        'button' => [
            'ok' => 'Ok',
            'confirm' => 'Xác nhận',
            'cancel' => 'Hủy',
        ],
    ],

    'command-palette' => [
        'search' => 'Tìm kiếm...',
        'empty' => 'Không tìm thấy kết quả.',
        'navigate' => 'điều hướng',
        'select' => 'chọn',
        'close' => 'đóng',
    ],

    'table' => [
        'empty' => 'Không tìm thấy kết quả.',
        'quantity' => 'Số lượng',
        'search' => 'Tìm kiếm ở đây',
    ],

    'clipboard' => [
        'button' => [
            'copy' => 'Sao chép',
            'copied' => 'Đã sao chép!',
        ],
    ],

    'password' => [
        'rules' => [
            'title' => 'Định dạng mật khẩu mong đợi:',
            'formats' => [
                'min' => 'Ít nhất :min ký tự',
                'numbers' => 'Ít nhất một số',
                'symbols' => 'Ít nhất một ký tự đặc biệt (:symbols)',
                'mixed' => 'Chữ hoa và chữ thường',
            ],
        ],
    ],

    'upload' => [
        'placeholder' => 'Chọn một tệp',
        'size' => 'Kích thước',
        'upload' => 'Nhấp vào đây để tải lên',
        'uploaded' => [
            'single' => ':count tệp đã gửi',
            'multiple' => ':count tệp đã gửi',
        ],
        'error' => 'Đã xảy ra lỗi. Vui lòng thử lại.',
        'static' => [
            'empty' => [
                'title' => 'Không có hình ảnh.',
                'description' => 'Bạn chưa có bất kỳ hình ảnh nào.',
            ],
        ],
        'invalid' => 'Đã xảy ra lỗi xác thực.',
    ],

    'upload_async' => [
        'title' => 'Thả tệp vào đây',
        'description' => 'hoặc nhấp để chọn',
        'send' => 'Gửi',
        'clear' => 'Xóa',
        'ready' => [
            'single' => ':count tệp sẵn sàng · :size',
            'multiple' => ':count tệp sẵn sàng · :size',
        ],
        'errors' => [
            'mime' => 'Loại tệp không được phép.',
            'size' => 'Tệp vượt quá giới hạn :max MB.',
            'limit' => 'Bạn chỉ có thể tải lên tối đa :max tệp.',
            'network' => 'Lỗi mạng. Vui lòng thử lại.',
            'server' => 'Tải lên thất bại. Vui lòng thử lại.',
            'integrity' => 'Tệp tải lên bị thiếu dữ liệu. Vui lòng thử lại.',
            'unauthorized' => 'Bạn không được phép tải lên tệp này.',
            'generic' => 'Đã xảy ra lỗi.',
        ],
    ],

    'date' => [
        'calendar' => [
            'months' => [
                'january' => 'Tháng Một',
                'february' => 'Tháng Hai',
                'march' => 'Tháng Ba',
                'april' => 'Tháng Tư',
                'may' => 'Tháng Năm',
                'june' => 'Tháng Sáu',
                'july' => 'Tháng Bảy',
                'august' => 'Tháng Tám',
                'september' => 'Tháng Chín',
                'october' => 'Tháng Mười',
                'november' => 'Tháng Mười Một',
                'december' => 'Tháng Mười Hai',
            ],
            'week' => [
                'sunday' => 'Chủ Nhật',
                'monday' => 'Thứ Hai',
                'tuesday' => 'Thứ Ba',
                'wednesday' => 'Thứ Tư',
                'thursday' => 'Thứ Năm',
                'friday' => 'Thứ Sáu',
                'saturday' => 'Thứ Bảy',
            ],
        ],
        'helpers' => [
            'yesterday' => 'Hôm qua',
            'today' => 'Hôm nay',
            'tomorrow' => 'Ngày mai',
        ],
    ],

    'time' => [
        'helper' => 'Thời gian hiện tại',
    ],

    'step' => [
        'next' => 'Tiếp theo',
        'previous' => 'Trước đó',
        'finish' => 'Hoàn thành',
    ],

    'key-value' => [
        'headers' => [
            'key' => 'KHÓA',
            'value' => 'GIÁ TRỊ',
        ],
        'placeholders' => [
            'key' => 'Nhập khóa',
            'value' => 'Nhập giá trị',
        ],
        'add-row' => 'THÊM DÒNG',
        'empty' => 'Chưa thêm dòng nào.',
    ],

    'currency' => [
        'symbol' => '₫',
        'currency' => 'VND',
    ],

    'list' => [
        'search' => 'Tìm kiếm',
        'empty' => 'Không có mục nào.',
    ],
];
