<?php

namespace TallStackUi\Components\Dialog;

use Laravel\Dusk\Browser;
use Livewire\Component;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use TallStackUi\Traits\Interactions;
use Tests\Browser\BrowserTestCase;

class BrowserTest extends BrowserTestCase
{
    #[Test]
    public function can_accept_interaction_dialog_with_enter(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function cancelled(string $message): void
            {
                $this->dialog()->error($message)->send();
            }

            public function confirm(): void
            {
                $this->dialog()
                    ->question('Foo bar confirmation', 'Are you sure?')
                    ->confirm('Yes', 'confirmed', 'Confirmed with enter')
                    ->cancel('No', 'cancelled', 'Cancelled with enter')
                    ->send();
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Foo bar confirmation')
            ->click('@confirm')
            ->waitForText('Foo bar confirmation')
            ->assertSee('Are you sure?')
            ->keys('', '{enter}')
            ->waitForText('Confirmed with enter')
            ->assertSee('Confirmed with enter')
            ->assertDontSee('Cancelled with enter');
    }

    #[Test]
    public function can_accept_persistent_interaction_dialog_with_confirmation(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function confirm(): void
            {
                $this->dialog()
                    ->persistent()
                    ->question('Persistent Confirm', 'Are you sure?')
                    ->confirm('Yes', 'confirmed', 'Confirmed persistent')
                    ->cancel('No', 'cancelled', 'Cancelled persistent')
                    ->send();
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function cancelled(string $message): void
            {
                $this->dialog()->error($message)->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent Confirm')
            ->click('@confirm')
            ->waitForText('Persistent Confirm')
            ->assertSee('Are you sure?')
            ->click('@tallstackui_dialog_confirmation')
            ->waitForText('Confirmed persistent')
            ->assertSee('Confirmed persistent');
    }

    #[Test]
    public function can_accept_persistent_interaction_dialog_with_enter(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function confirm(): void
            {
                $this->dialog()
                    ->persistent()
                    ->question('Persistent Confirm', 'Are you sure?')
                    ->confirm('Yes', 'confirmed', 'Confirmed persistent with enter')
                    ->send();
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent Confirm')
            ->click('@confirm')
            ->waitForText('Persistent Confirm')
            ->assertSee('Are you sure?')
            ->keys('', '{enter}')
            ->waitForText('Confirmed persistent with enter')
            ->assertSee('Confirmed persistent with enter');
    }

    #[Test]
    public function can_be_opened_using_modal_and_close_the_dialog_instead_of_modal(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function confirm(): void
            {
                $this->dialog()
                    ->success('Foo bar confirmation', 'Foo bar confirmation description')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" x-on:click="$tsui.open.modal('dialog')">Open</x-button>

                    <x-modal title="Modal" id="dialog" z-index="z-40">
                        <x-button dusk="confirming" wire:click="confirm">Click here to confirm</x-button>
                    </x-modal>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Modal')
            ->assertDontSee('Click here to confirm')
            ->assertDontSee('Foo bar confirmation')
            ->click('@confirm')
            ->waitForText('Modal')
            ->assertSee('Modal')
            ->assertSee('Click here to confirm')
            ->waitForLivewire()->click('@confirming')
            ->waitForText('Foo bar confirmation')
            ->assertSee('Foo bar confirmation')
            ->clickAtPoint(350, 350)
            ->waitUntilMissingText('Foo bar confirmation')
            ->assertSee('Modal')
            ->assertSee('Click here to confirm');
    }

    #[Test]
    public function can_be_opened_using_slide_and_close_the_dialog_instead_of_slide(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function confirm(): void
            {
                $this->dialog()
                    ->success('Foo bar confirmation', 'Foo bar confirmation description')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" x-on:click="$tsui.open.slide('dialog')">Open</x-button>

                    <x-slide title="Slide" id="dialog" z-index="z-40">
                        <x-button dusk="confirming" wire:click="confirm">Click here to confirm</x-button>
                    </x-slide>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Slide')
            ->assertDontSee('Click here to confirm')
            ->assertDontSee('Foo bar confirmation')
            ->click('@confirm')
            ->waitForText('Slide')
            ->assertSee('Slide')
            ->assertSee('Click here to confirm')
            ->waitForLivewire()->click('@confirming')
            ->waitForText('Foo bar confirmation')
            ->assertSee('Foo bar confirmation')
            ->clickAtPoint(350, 350)
            ->waitUntilMissingText('Foo bar confirmation')
            ->assertSee('Slide')
            ->assertSee('Click here to confirm');
    }

    #[Test]
    public function can_close_interaction_dialog_with_enter(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }

            public function success(): void
            {
                $this->dialog()->success('Foo bar success', 'Foo bar success description')->send();
            }
        })
            ->assertDontSee('Foo bar success')
            ->click('@success')
            ->waitForText('Foo bar success')
            ->assertSee('Foo bar success')
            ->keys('', '{enter}')
            ->waitUntilMissingText('Foo bar success')
            ->assertDontSee('Foo bar success');
    }

    #[Test]
    public function can_close_interaction_dialog_with_escape(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function success(): void
            {
                $this->dialog()->success('Foo bar success', 'Foo bar success description')->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Foo bar success')
            ->click('@success')
            ->waitForText('Foo bar success')
            ->assertSee('Foo bar success')
            ->keys('', '{escape}')
            ->waitUntilMissingText('Foo bar success')
            ->assertDontSee('Foo bar success');
    }

    #[Test]
    public function can_close_persistent_interaction_dialog_by_clicking_close_button(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function success(): void
            {
                $this->dialog()
                    ->persistent()
                    ->success('Persistent Close Button')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent Close Button')
            ->click('@success')
            ->waitForText('Persistent Close Button')
            ->assertSee('Persistent Close Button')
            ->click('@tallstackui_dialog_close')
            ->waitUntilMissingText('Persistent Close Button')
            ->assertDontSee('Persistent Close Button');
    }

    #[Test]
    public function can_close_persistent_interaction_dialog_by_clicking_ok_button(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function success(): void
            {
                $this->dialog()
                    ->persistent()
                    ->success('Persistent OK Button')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent OK Button')
            ->click('@success')
            ->waitForText('Persistent OK Button')
            ->assertSee('Persistent OK Button')
            ->click('@tallstackui_dialog_confirmation')
            ->waitUntilMissingText('Persistent OK Button')
            ->assertDontSee('Persistent OK Button');
    }

    #[Test]
    public function can_dispatch_confirmation_dialog_without_livewire_specifing_component_id(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" onclick="confirm()">Confirm</x-button>
                    
                    <script>
                        confirm = () => $tsui.interaction('dialog').question('Confirm?')
                            .wireable(Livewire.first().id)
                            .confirm('Confirm', 'confirmed', 'Confirmed Without Livewire')
                            .cancel('Cancel', 'cancelled', 'Cancelled Without Livewire')
                            .send();
                    </script>
                </div>
                HTML;
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function cancelled(string $message): void
            {
                $this->dialog()->error($message)->send();
            }
        })
            ->assertDontSee('Confirm?')
            ->assertDontSee('Confirmed Without Livewire')
            ->click('@confirm')
            ->waitForText('Confirm?')
            ->click('@tallstackui_dialog_confirmation')
            ->waitForText('Confirmed Without Livewire')
            ->assertSee('Confirmed Without Livewire')
            ->click('@tallstackui_dialog_confirmation')
            ->click('@confirm')
            ->waitForText('Confirm?')
            ->click('@tallstackui_dialog_rejection')
            ->waitForText('Cancelled Without Livewire')
            ->assertSee('Cancelled Without Livewire');
    }

    #[Test]
    public function can_dispatch_confirmation_dialog_without_livewire_using_first_component_in_page(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" onclick="confirm()">Confirm</x-button>
                    
                    <script>
                        confirm = () => $tsui.interaction('dialog').question('Confirm?')
                            .wireable()
                            .confirm('Confirm', 'confirmed', 'Confirmed Without Livewire')
                            .cancel('Cancel', 'cancelled', 'Cancelled Without Livewire')
                            .send();
                    </script>
                </div>
                HTML;
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }
        })
            ->assertDontSee('Confirm?')
            ->assertDontSee('Confirmed Without Livewire')
            ->click('@confirm')
            ->waitForText('Confirm?')
            ->click('@tallstackui_dialog_confirmation')
            ->waitForText('Confirmed Without Livewire')
            ->assertSee('Confirmed Without Livewire');
    }

    #[Test]
    public function can_dispatch_dialog_without_livewire(): void
    {
        Livewire::visit(new class extends Component
        {
            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" x-on:click="$tsui.interaction('dialog').success('Success Without Livewire').send()">Success</x-button>
                    <x-button dusk="error" x-on:click="$tsui.interaction('dialog').error('Error Without Livewire').send()">Error</x-button>
                    <x-button dusk="info" x-on:click="$tsui.interaction('dialog').info('Info Without Livewire').send()">Info</x-button>
                    <x-button dusk="warning" x-on:click="$tsui.interaction('dialog').warning('Warning Without Livewire').send()">Error</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Success Without Livewire')
            ->click('@success')
            ->waitForText('Success Without Livewire')
            ->click('@tallstackui_dialog_confirmation')
            ->assertDontSee('Error Without Livewire')
            ->click('@error')
            ->waitForText('Error Without Livewire')
            ->click('@tallstackui_dialog_confirmation')
            ->assertDontSee('Info Without Livewire')
            ->click('@info')
            ->waitForText('Info Without Livewire')
            ->click('@tallstackui_dialog_confirmation')
            ->assertDontSee('Warning Without Livewire')
            ->click('@warning')
            ->waitForText('Warning Without Livewire')
            ->click('@tallstackui_dialog_confirmation');
    }

    #[Test]
    public function can_dispatch_dismissed_event(): void
    {
        $this->skipOnGitHubActions();

        Livewire::visit(new class extends Component
        {
            use Interactions;

            public ?string $target = null;

            public function success(): void
            {
                $this->dialog()->success('Foo bar success', 'Foo bar success description')->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div x-on:dialog:dismissed.window="$wire.set('target', 'Dismissed')">
                    @if ($target)
                        <p dusk="target">{{ $target }}</p>
                    @endif
                
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertNotPresent('@target')
            ->assertSee('Success')
            ->click('@success')
            ->waitForAllText(['Foo bar success', 'Foo bar success description'])
            ->assertSee('Foo bar success')
            ->assertSee('Foo bar success description')
            ->clickAtPoint(350, 350)
            ->pause(100)
            ->assertPresent('@target');
    }

    #[Test]
    public function can_dispatch_dismissed_event_when_closing_with_escape(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public ?string $target = null;

            public function success(): void
            {
                $this->dialog()->success('Foo bar success', 'Foo bar success description')->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div x-on:dialog:dismissed.window="$wire.set('target', 'Dismissed')">
                    @if ($target)
                        <p dusk="target">{{ $target }}</p>
                    @endif

                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertNotPresent('@target')
            ->click('@success')
            ->waitForText('Foo bar success')
            ->keys('', '{escape}')
            ->waitForText('Dismissed')
            ->assertPresent('@target');
    }

    #[Test]
    public function can_dispatch_events(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public string $target = '';

            public function cancelled(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function confirm(): void
            {
                $this->dialog()
                    ->question('Foo bar confirmation', 'Foo bar confirmation description')
                    ->confirm('Confirm', 'confirmed', 'Foo bar confirmed foo')
                    ->cancel('Cancel', 'cancelled', 'Bar foo cancelled bar')
                    ->send();
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div x-on:dialog:accepted.window="$wire.set('target', 'Accepted')" 
                     x-on:dialog:rejected.window="$wire.set('target', 'Rejected')">
                    <p dusk="target">{{ $target }}</p>
                
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Accepted')
            ->assertDontSee('Rejected')
            ->assertSee('Confirm')
            ->click('@confirm')
            ->waitForText('Foo bar confirmation')
            ->assertSee('Foo bar confirmation')
            ->click('@tallstackui_dialog_confirmation')
            ->waitForText('Accepted')
            ->assertSeeIn('@target', 'Accepted')
            ->waitForText('Foo bar confirmed foo')
            ->assertSee('Foo bar confirmed foo')
            ->click('@tallstackui_dialog_confirmation')
            ->click('@confirm')
            ->waitForText('Foo bar confirmation')
            ->assertSee('Foo bar confirmation')
            ->click('@tallstackui_dialog_rejection')
            ->waitForText('Rejected')
            ->assertSee('Rejected')
            ->waitForText('Bar foo cancelled bar')
            ->assertSee('Bar foo cancelled bar');
    }

    #[Test]
    public function can_display_flash_on_livewire_navigated_event(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function storeFlash(): void
            {
                $this->dialog()
                    ->success('Flash Dialog Navigate', 'Flash dialog navigate description')
                    ->flash()
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <script>
                        // Prevent window.onload from triggering flash (simulates SPA navigation where onload does not fire)
                        Object.defineProperty(window, 'onload', { set() {}, get() { return null; }, configurable: true });
                        // Block the first livewire:navigated so the dialog's {once:true} listener is preserved for manual dispatch
                        document.addEventListener('livewire:navigated', (e) => e.stopImmediatePropagation(), { capture: true, once: true });
                    </script>
                    <x-button dusk="flash" wire:click="storeFlash">Store Flash</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Flash Dialog Navigate')
            ->waitForLivewire()->click('@flash')
            ->refresh()
            ->pause(500)
            ->assertDontSee('Flash Dialog Navigate')
            ->tap(fn (Browser $browser) => $browser->script("document.dispatchEvent(new Event('livewire:navigated'))"))
            ->waitForText('Flash Dialog Navigate')
            ->assertSee('Flash Dialog Navigate');
    }

    #[Test]
    public function can_display_flash_on_page_reload(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function storeFlash(): void
            {
                $this->dialog()
                    ->success('Flash Dialog Reload', 'Flash dialog description')
                    ->flash()
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="flash" wire:click="storeFlash">Store Flash</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Flash Dialog Reload')
            ->waitForLivewire()->click('@flash')
            ->refresh()
            ->waitForText('Flash Dialog Reload', 10)
            ->assertSee('Flash Dialog Reload')
            ->assertSee('Flash dialog description');
    }

    #[Test]
    public function can_reject_persistent_interaction_dialog_with_confirmation(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function confirm(): void
            {
                $this->dialog()
                    ->persistent()
                    ->question('Persistent Reject', 'Are you sure?')
                    ->confirm('Yes', 'confirmed', 'Confirmed persistent')
                    ->cancel('No', 'cancelled', 'Cancelled persistent')
                    ->send();
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function cancelled(string $message): void
            {
                $this->dialog()->error($message)->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent Reject')
            ->click('@confirm')
            ->waitForText('Persistent Reject')
            ->assertSee('Are you sure?')
            ->click('@tallstackui_dialog_rejection')
            ->waitForText('Cancelled persistent')
            ->assertSee('Cancelled persistent');
    }

    #[Test]
    public function can_send(): void
    {
        Livewire::visit(DialogComponent::class)
            ->assertDontSee('Foo bar success')
            ->click('@success')
            ->waitForText('Foo bar success')
            ->click('@tallstackui_dialog_confirmation')
            ->assertDontSee('Foo bar error')
            ->click('@error')
            ->waitForText('Foo bar error')
            ->click('@tallstackui_dialog_confirmation')
            ->assertDontSee('Foo bar info')
            ->click('@info')
            ->waitForText('Foo bar info')
            ->click('@tallstackui_dialog_confirmation')
            ->assertDontSee('Foo bar warning')
            ->click('@warning')
            ->waitForText('Foo bar warning')
            ->click('@tallstackui_dialog_confirmation');
    }

    #[Test]
    public function can_send_cancellation(): void
    {
        Livewire::visit(DialogComponent::class)
            ->assertDontSee('Foo bar confirmation description')
            ->click('@confirm')
            ->waitForText('Foo bar confirmation description')
            ->click('@tallstackui_dialog_rejection')
            ->waitForText('Bar foo cancelled bar');
    }

    #[Test]
    public function can_send_confirmation(): void
    {
        Livewire::visit(DialogComponent::class)
            ->assertDontSee('Foo bar confirmation description')
            ->click('@confirm')
            ->waitForText('Foo bar confirmation description')
            ->click('@tallstackui_dialog_confirmation')
            ->waitUntilMissingText('Foo bar confirmation description');
    }

    #[Test]
    public function can_use_close_hook(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public ?string $close = null;

            public function success(): void
            {
                $this->dialog()
                    ->success('Foo!')
                    ->hook([
                        'close' => [
                            'method' => 'closed',
                            'params' => 'close',
                        ],
                    ])
                    ->send();
            }

            public function closed(string $term): void
            {
                $this->close = $term;
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <p dusk="close">{{ $close }}</p>
                
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('close')
            ->assertDontSee('Foo')
            ->assertSee('Success')
            ->click('@success')
            ->waitForText('Foo')
            ->assertSee('Foo')
            ->click('@tallstackui_dialog_close')
            ->waitForTextIn('@close', 'close')
            ->assertSee('close');
    }

    #[Test]
    public function can_use_dismiss_hook(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public bool $dismiss = false;

            public function success(): void
            {
                $this->dialog()
                    ->success('Foo!')
                    ->hook([
                        'dismiss' => [
                            'method' => 'dismissed',
                            'params' => 'dismiss',
                        ],
                    ])
                    ->send();
            }

            public function dismissed(): void
            {
                $this->dismiss = true;
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    @if ($dismiss)
                      <p dusk="dismiss">Dismissed</p>
                    @endif
                
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('dismiss')
            ->assertDontSee('Foo')
            ->assertSee('Success')
            ->click('@success')
            ->waitForText('Foo')
            ->assertSee('Foo')
            ->clickAtPoint(350, 350)
            ->waitForTextIn('@dismiss', 'Dismissed')
            ->assertSee('Dismissed');
    }

    #[Test]
    public function can_use_ok_hook(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public ?string $ok = null;

            public function success(): void
            {
                $this->dialog()
                    ->success('Foo!')
                    ->hook([
                        'ok' => [
                            'method' => 'pressed',
                            'params' => 'ok',
                        ],
                    ])
                    ->send();
            }

            public function pressed(string $term): void
            {
                $this->ok = $term;
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <p dusk="ok">{{ $ok }}</p>
                
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('ok')
            ->assertDontSee('Foo')
            ->assertSee('Success')
            ->click('@success')
            ->waitForText('Foo')
            ->assertSee('Foo')
            ->click('@tallstackui_dialog_confirmation')
            ->waitForTextIn('@ok', 'ok')
            ->assertSee('ok');
    }

    #[Test]
    public function cannot_accept_interaction_dialog_with_enter_when_the_focus_is_inside_the_dialog(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function cancelled(string $message): void
            {
                $this->dialog()->error($message)->send();
            }

            public function confirm(): void
            {
                $this->dialog()
                    ->question('Foo bar confirmation', 'Are you sure?')
                    ->confirm('Yes', 'confirmed', 'Confirmed with enter')
                    ->cancel('No', 'cancelled', 'Cancelled with enter')
                    ->send();
            }

            public function confirmed(string $message): void
            {
                $this->dialog()->success($message)->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->click('@confirm')
            ->waitForText('Foo bar confirmation')
            ->keys('@tallstackui_dialog_rejection', '{enter}')
            ->waitForText('Cancelled with enter')
            ->assertSee('Cancelled with enter')
            ->assertDontSee('Confirmed with enter');
    }

    #[Test]
    public function cannot_close_persistent_interaction_dialog_by_clicking_outside(): void
    {
        $this->skipOnGitHubActions();

        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function success(): void
            {
                $this->dialog()
                    ->persistent()
                    ->success('Persistent Dialog', 'This should not close on outside click')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent Dialog')
            ->click('@success')
            ->waitForText('Persistent Dialog')
            ->assertSee('This should not close on outside click')
            ->clickAtPoint(350, 350)
            ->pause(300)
            ->assertSee('Persistent Dialog')
            ->assertSee('This should not close on outside click');
    }

    #[Test]
    public function cannot_close_persistent_interaction_dialog_with_escape(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function success(): void
            {
                $this->dialog()
                    ->persistent()
                    ->success('Persistent Dialog', 'This should not close on escape')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Persistent Dialog')
            ->click('@success')
            ->waitForText('Persistent Dialog')
            ->assertSee('This should not close on escape')
            ->keys('', '{escape}')
            ->pause(300)
            ->assertSee('Persistent Dialog')
            ->assertSee('This should not close on escape');
    }

    #[Test]
    public function cannot_close_when_dialog_is_persistent(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function success(): void
            {
                $this->dialog()
                    ->persistent()
                    ->success('Foo bar success')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="success" wire:click="success">Success</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Foo bar success')
            ->click('@success')
            ->waitForText('Foo bar success')
            ->assertSee('Foo bar success')
            ->clickAtPoint(350, 350)
            ->pause(300)
            ->assertSee('Foo bar success');
    }

    #[Test]
    public function cannot_see_cancellation_if_it_was_not_defined(): void
    {
        Livewire::visit(new class extends Component
        {
            use Interactions;

            public function confirm(): void
            {
                $this->dialog()
                    ->question('Foo bar confirmation', 'Foo bar confirmation description')
                    ->confirm('Confirm', 'confirmed', 'Foo bar confirmed foo')
                    ->send();
            }

            public function render(): string
            {
                return <<<'HTML'
                <div>
                    <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
                </div>
                HTML;
            }
        })
            ->assertDontSee('Foo bar confirmation')
            ->click('@confirm')
            ->waitForText('Foo bar confirmation')
            ->assertSee('Foo bar confirmation')
            ->assertSee('Foo bar confirmation description')
            ->assertDontSee('Cancelled');
    }
}

class DialogComponent extends Component
{
    use Interactions;

    public function cancelled(string $message): void
    {
        $this->dialog()->success($message)->send();
    }

    public function confirm(): void
    {
        $this->dialog()
            ->question('Foo bar confirmation', 'Foo bar confirmation description')
            ->confirm('Confirm', 'confirmed', 'Foo bar confirmed foo')
            ->cancel('Cancel', 'cancelled', 'Bar foo cancelled bar')
            ->send();
    }

    public function confirmed(string $message): void
    {
        $this->dialog()->success($message)->send();
    }

    public function error(): void
    {
        $this->dialog()->error('Foo bar error')->send();
    }

    public function info(): void
    {
        $this->dialog()->info('Foo bar info')->send();
    }

    public function render(): string
    {
        return <<<'HTML'
        <div>
            <x-button dusk="success" wire:click="success">Success</x-button>
            <x-button dusk="error" wire:click="error">Error</x-button>
            <x-button dusk="info" wire:click="info">Info</x-button>
            <x-button dusk="warning" wire:click="warning">Error</x-button>
            <x-button dusk="confirm" wire:click="confirm">Confirm</x-button>
        </div>
        HTML;
    }

    public function success(): void
    {
        $this->dialog()->success('Foo bar success')->send();
    }

    public function warning(): void
    {
        $this->dialog()->warning('Foo bar warning')->send();
    }
}
