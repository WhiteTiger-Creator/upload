@php
    $customization = $classes();
@endphp

<x-dynamic-component :component="TallStackUi::prefix('wrapper.input')" :$id :$property :$error :$label :$hint
                     :$invalidate>
    <div @class([
            $customization['input.wrapper'],
            $customization['input.color.base'] => !$error,
            $customization['input.color.background'] => !$attributes->get('disabled') && !$attributes->get('readonly'),
            $customization['input.color.disabled'] => $attributes->get('disabled') || $attributes->get('readonly'),
            $customization['error'] => $error === true
        ]) x-data="tallstackui_formNumber({!! $entangle !!}, @js($min), @js($max), @js($delay), @js($step), @js($debounce))">
        <div @class([$customization['buttons.wrapper'], $customization['input.wrapper-centralized'] => $centralized])>
            <input @if ($id) id="{{ $id }}" @endif
            type="number"
                   inputmode="{{ $mode() }}"
                   pattern="{{ $pattern() }}"
                   @if ($min) min="{{ $min }}" @endif
                   @if ($max) max="{{ $max }}" @endif
                   @if ($step) step="{{ $step }}" @endif
                   @if ($selectable) x-on:keydown="$event.preventDefault()" @endif
                   {{ $attributes->class([
                        $customization['input.base'],
                        $customization['input.centralized'] => $centralized,
                        $customization['input.caret'] => $selectable,
                        $customization['input.appearance']
                    ])}}
                   dusk="tallstackui_form_number_input"
                   x-on:blur="validate()"
                   x-ref="input">
            <button @if (!$attributes->get('disabled', $attributes->get('readonly', false))) x-on:click="decrement()"
                    @endif
                    x-on:pointerdown="if (!interval) interval = setInterval(() => decrement(), delay * 100);"
                    x-on:pointerup="if (interval) { clearInterval(interval); interval = null; }"
                    x-on:pointerleave="if (interval) { clearInterval(interval); interval = null; }"
                    x-on:pointercancel="if (interval) { clearInterval(interval); interval = null; }"
                    x-ref="minus"
                    type="button"
                    @disabled($attributes->get('disabled', $attributes->get('readonly', false)))
                    dusk="tallstackui_form_number_decrement"
                    @class([$customization['buttons.left.base'], $customization['buttons.left.centralized'] => $centralized])>
                <x-dynamic-component :component="TallStackUi::prefix('icon')"
                                     :icon="$icons['left']"
                                     internal
                        @class([$customization['buttons.left.size'], $customization['buttons.left.color'] => !$error, $customization['buttons.left.error'] => $error]) />
            </button>
            <button @if (!$attributes->get('disabled', $attributes->get('readonly', false))) x-on:click="increment()"
                    @endif
                    x-on:pointerdown="if (!interval) interval = setInterval(() => increment(), delay * 100);"
                    x-on:pointerup="if (interval) { clearInterval(interval); interval = null; }"
                    x-on:pointerleave="if (interval) { clearInterval(interval); interval = null; }"
                    x-on:pointercancel="if (interval) { clearInterval(interval); interval = null; }"
                    x-ref="plus"
                    type="button"
                    @disabled($attributes->get('disabled', $attributes->get('readonly', false)))
                    dusk="tallstackui_form_number_increment"
                    @class([$customization['buttons.right.base'], $customization['buttons.right.separator'] => !$centralized])>
                <x-dynamic-component :component="TallStackUi::prefix('icon')"
                                     :icon="$icons['right']"
                                     internal
                        @class([$customization['buttons.right.size'], $customization['buttons.right.color'] => !$error, $customization['buttons.right.error'] => $error]) />
            </button>
        </div>
    </div>
</x-dynamic-component>
