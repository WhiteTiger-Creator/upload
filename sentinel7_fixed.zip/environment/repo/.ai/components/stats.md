# TallStackUI: Stats

> TallStackUI is a TALL Stack (Tailwind CSS, Alpine.js, Laravel, Livewire)
> component library providing 65+ Blade components for building modern web interfaces.

A statistics card component for displaying numeric metrics with titles, icons, and trend indicators. Supports solid, light, and outline styles, animated number counting, colorized number text, and optional link/click behavior with Livewire navigation.

## Basic Usage

```blade
<x-stats number="1234" title="Total Users" icon="users" />
```

```blade
<x-stats number="89" title="Conversion Rate" icon="chart-bar" color="green" increase />
```

```blade
<x-stats number="42" title="Open Issues" color="red" outline decrease animated :duration="2" />
```

```blade
<x-stats number="567" title="Revenue" href="/reports" navigate>
    <x-slot:header>Monthly Report</x-slot:header>
    <x-slot:footer>Updated 5 min ago</x-slot:footer>
</x-stats>
```

```blade
{{-- Default slot is unstyled (free markup). Use :number for styled values. --}}
<x-stats header="Revenue" footer="This month">
    <p class="text-2xl font-bold text-primary-500">R$ 333,55</p>
</x-stats>
```

```blade
{{-- Livewire click stays a <div> (not <a>); cursor-pointer is applied --}}
<x-stats number="10" wire:click="refresh" />
```

## Attributes

| Attribute      | Type                        | Default   | Description                                                                  |
|----------------|-----------------------------|-----------|------------------------------------------------------------------------------|
| number         | string\|int\|null           | null      | Value shown with number styles; preferred path for styled metrics            |
| title          | string\|null                | null      | Descriptive title above/beside the number                                    |
| icon           | ComponentSlot\|string\|null | null      | Heroicon name or a slot for fully custom icon markup                         |
| color          | string\|null                | 'primary' | Color for icon background **and** number text (solid/light/outline palettes) |
| href           | string\|null                | null      | When set, root renders as `<a>` for click-through                            |
| solid          | bool                        | true      | Solid color style variant (default)                                          |
| light          | bool                        | false     | Light color style variant                                                    |
| outline        | bool                        | false     | Outline color style variant                                                  |
| animated       | bool                        | false     | Count-up animation on viewport enter; **only when `number` is numeric**      |
| duration       | int\|null                   | 1         | Animation duration in seconds (ignored when not animating)                   |
| increase       | bool                        | false     | Upward trend arrow on the right (mutually exclusive with `decrease`)         |
| decrease       | bool                        | false     | Downward trend arrow on the right (mutually exclusive with `increase`)       |
| navigate       | bool                        | null      | Livewire `wire:navigate` when using `href`                                   |
| navigate-hover | bool                        | null      | Livewire `wire:navigate.hover` when using `href`                             |

### Root element

| Condition                               | Tag     | Notes                                  |
|-----------------------------------------|---------|----------------------------------------|
| `href` filled                           | `<a>`   | Optional `navigate` / `navigate-hover` |
| `wire:click` / `x-on:click` (no `href`) | `<div>` | Still gets `cursor-pointer`            |
| Neither                                 | `<div>` | Static card                            |

## Slots

| Slot      | Description                                                                                          |
|-----------|------------------------------------------------------------------------------------------------------|
| (default) | Free markup replacing the number area — **no** default number styles applied                         |
| header    | Above the body (string prop or slot); strings get muted text styles; slots keep positioning wrappers |
| footer    | Below the body (string prop or slot); same styling rules as header                                   |
| right     | Right side content (replaces increase/decrease arrow)                                                |
| icon      | Fully custom icon markup (replaces default icon rendering)                                           |

String props `header="..."` / `footer="..."` and named slots both render with horizontal inset (`mx-2`) and muted typography for plain text.

## Soft Customization

Soft customization allows you to override default Tailwind CSS classes used by this component at runtime, either through a service provider or scoped per-instance.

### Customization

```php
TallStackUi::customize()
    ->stats()
    ->block('wrapper.first', 'your-tailwind-classes');
```

### Available Blocks

| Block Name                 | Purpose                                                                   |
|----------------------------|---------------------------------------------------------------------------|
| wrapper.first              | Outer card container (flex column, rounded, shadow)                       |
| wrapper.first-clickable    | Cursor style when the card is clickable                                   |
| wrapper.second             | Body row (includes horizontal margin `mx-4`, flex, gap)                   |
| wrapper.second-no-header   | Extra top margin when header is absent                                    |
| wrapper.second-no-footer   | Extra bottom margin when footer is absent                                 |
| wrapper.third              | Icon container (flex, centered, rounded, dimensions)                      |
| slots.header.wrapper       | Outer inset around header                                                 |
| slots.header.text          | Header typography (string props / plain slot text)                        |
| slots.footer.wrapper       | Outer inset around footer                                                 |
| slots.footer.text          | Footer typography (string props / plain slot text)                        |
| slots.right.increase.icon  | Increase trend arrow icon name                                            |
| slots.right.increase.class | Increase trend arrow icon styles                                          |
| slots.right.decrease.icon  | Decrease trend arrow icon name                                            |
| slots.right.decrease.class | Decrease trend arrow icon styles                                          |
| icon                       | Icon dimensions inside the icon container                                 |
| title                      | Title text styles                                                         |
| number                     | Number layout styles (size/weight/leading; color comes from `color` prop) |

### Soft key renames (v4)

| Removed                       | Replacement                                    |
|-------------------------------|------------------------------------------------|
| `slots.header`                | `slots.header.text`                            |
| `slots.header-string-wrapper` | `slots.header.wrapper`                         |
| `slots.footer`                | `slots.footer.text`                            |
| `slots.footer-string-wrapper` | `slots.footer.wrapper`                         |
| `wrapper.second-no-slot`      | removed (`mx-4` is always on `wrapper.second`) |

### Predefined scope

`scope="stats-shadowless"` — removes card shadow and adds a light border (registered in the service provider).
