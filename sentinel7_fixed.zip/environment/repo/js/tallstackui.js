import './globals/globals';
import alpineCollapse from '@alpinejs/collapse';
import accordion from '../src/Components/Accordion/alpine';
import alert from '../src/Components/Alert/alpine';
import autocomplete from '../src/Components/Form/Autocomplete/alpine';
import backToTop from '../src/Components/BackToTop/alpine';
import banner from '../src/Components/Banner/alpine';
import carousel from '../src/Components/Carousel/alpine';
import card from '../src/Components/Card/alpine';
import color from '../src/Components/Form/Color/alpine';
import collapse from '../src/Components/Layout/SideBar/Main/collapse';
import currency from '../src/Components/Form/Currency/alpine';
import darkTheme from './helpers/dark-theme';
import dial from '../src/Components/Dial/Main/alpine';
import dialog from '../src/Components/Dialog/alpine';
import dropdown from '../src/Components/Dropdown/Main/alpine';
import floating from '../src/Components/Floating/alpine';
import clearable from '../src/Components/Form/Input/clearable';
import stripZeros from '../src/Components/Form//Input/strip-zeros';
import loading from '../src/Components/Loading/alpine';
import layout from '../src/Components/Layout/Main/alpine';
import list from '../src/Components/List/Main/alpine';
import keyValue from '../src/Components/KeyValue/alpine';
import modal from '../src/Components/Modal/alpine';
import number from '../src/Components/Form/Number/alpine';
import rating from '../src/Components/Rating/alpine';
import signature from '../src/Components/Signature/alpine';
import slide from '../src/Components/Slide/alpine';
import stats from '../src/Components/Stats/alpine';
import password from '../src/Components/Form/Password/alpine';
import pin from '../src/Components/Form/Pin/alpine';
import tab from '../src/Components/Tab/Main/alpine';
import table from '../src/Components/Table/alpine';
import tag from '../src/Components/Form/Tag/alpine';
import textArea from '../src/Components/Form/Textarea/alpine';
import toastBase from '../src/Components/Toast/toast-base';
import toastLoop from '../src/Components/Toast/toast-loop';
import { flush_ui_elements } from './helpers';

if (!window.__tsui_elements) {
  window.__tsui_elements = [];
}

document.addEventListener('livewire:navigating', flush_ui_elements);

window.tallstackui_floating = floating;

document.addEventListener('alpine:init', () => {
  Alpine.plugin(alpineCollapse);
  Alpine.data('tallstackui_accordion', accordion);
  Alpine.data('tallstackui_alert', alert);
  Alpine.data('tallstackui_autocomplete', autocomplete);
  Alpine.data('tallstackui_backToTop', backToTop);
  Alpine.data('tallstackui_banner', banner);
  Alpine.data('tallstackui_carousel', carousel);
  Alpine.data('tallstackui_card', card);
  Alpine.data('tallstackui_formColor', color);
  Alpine.data('tallstackui_formCurrency', currency);
  Alpine.data('tallstackui_formInputClearable', clearable);
  Alpine.data('tallstackui_formInputStripZeros', stripZeros);
  Alpine.data('tallstackui_formNumber', number);
  Alpine.data('tallstackui_formPassword', password);
  Alpine.data('tallstackui_formPin', pin);
  Alpine.data('tallstackui_formTag', tag);
  Alpine.data('tallstackui_formTextArea', textArea);
  Alpine.data('tallstackui_darkTheme', darkTheme);
  Alpine.data('tallstackui_dial', dial);
  Alpine.data('tallstackui_dialog', dialog);
  Alpine.data('tallstackui_dropdown', dropdown);
  Alpine.data('tallstackui_loading', loading);
  Alpine.data('tallstackui_layout', layout);
  Alpine.data('tallstackui_list', list);
  Alpine.data('tallstackui_keyValue', keyValue);
  Alpine.data('tallstackui_modal', modal);
  Alpine.data('tallstackui_rating', rating);
  Alpine.data('tallstackui_signature', signature);
  Alpine.data('tallstackui_slide', slide);
  Alpine.data('tallstackui_stats', stats);
  Alpine.data('tallstackui_tab', tab);
  Alpine.data('tallstackui_table', table);
  Alpine.data('tallstackui_toastBase', toastBase);
  Alpine.data('tallstackui_toastLoop', toastLoop);
  // Stores
  Alpine.store('tsui.side-bar', collapse);
});
