The `expect-puppeteer` package in `packages/expect-puppeteer` currently only knows how to assert against a Puppeteer `Page`, and its matchers act immediately against whatever is already rendered. We want to extend it so every matcher can accept either a `Page` or an `ElementHandle` as its context, and so the matchers wait for the target element to appear (up to a timeout that defaults to 500ms) before asserting rather than failing the instant it is not yet in the DOM. When given an `ElementHandle`, a matcher scopes its work to that element's subtree rather than the whole document.

Add a new `toMatchElement` matcher and its `not.toMatchElement` counterpart. `toMatchElement(selector, { text })` resolves the selector within the given context, optionally keeping only elements whose text matches `text`, waits until such an element exists, and resolves to the matched `ElementHandle`. `not.toMatchElement` waits until no matching element exists. The existing `notToMatch`, `toClick`, `toFill`, `toFillForm`, `toMatch`, `toSelect`, and `toUploadFile` matchers must accept both context types and wait before asserting; `toClick`, `toFill`, `toFillForm`, `toSelect`, and `toUploadFile` should locate their target through the same selector/text resolution as `toMatchElement`.

The public `expect` must recognize when its argument is a Puppeteer `Page` or `ElementHandle` and return the matching set of matchers; any other value keeps the original Jest behavior. Passing an unsupported Puppeteer-like value to the exported function should throw.

## Error messages

These strings are asserted by the tests and must match exactly:

- `toMatchElement` when nothing matches: `Element <selector> (text: "<text>") not found` when a `text` option is given, otherwise `Element <selector> not found`.
- `not.toMatchElement` when something matches: `Element <selector> (text: "<text>") found` with a `text` option, otherwise `Element <selector> found`.
- `toMatch` when the text is absent: `Text not found "<matcher>"`.
- `notToMatch` when the text is present: `Text found "<matcher>"`.
- `toSelect` when no option matches: `Option not found "<selector>" ("<valueOrText>")`.
- `toClick`, `toFill`, `toFillForm`, and `toUploadFile` surface the `toMatchElement` not-found message for their selector.

## Fixtures

Changes stay within the `expect-puppeteer` sources and the test fixtures. The sample markup that the `ElementHandle` tests exercise lives in `server/public/index.html`; it needs a `<main>` element containing some text and a nested `<div id="in-the-main">`. The suite runs headless against the local test server through Jest + Puppeteer, with a `Page` and an `ElementHandle` describe block for each matcher.
