#!/usr/bin/env bash
set -e
cd /app

# Apply the reference solution forward. Never reverse-apply: if the patch cannot be
# applied forward the tree is not in a state this script can fix, and undoing the
# solution would silently produce an unsolved tree that still exits 0.
if git apply -p1 --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --whitespace=nowarn /solution/golden.patch
elif git apply -p1 --3way --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --3way --whitespace=nowarn /solution/golden.patch
else
  echo "solve.sh: golden.patch does not apply forward to this tree" >&2
  exit 1
fi
