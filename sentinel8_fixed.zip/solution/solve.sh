#!/usr/bin/env bash
set -e
cd /app

# Apply the reference solution forward. The "already applied" case must be proven,
# not inferred from a failure: a reverse dry-run only succeeds on a tree that really
# does contain the patch. Anything else is a hard failure, so a patch that does not
# apply can never be graded as a solved tree.
if git apply -p1 --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --whitespace=nowarn /solution/golden.patch
elif git apply -p1 --3way --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --3way --whitespace=nowarn /solution/golden.patch
elif git apply -p1 -R --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  echo "solve.sh: golden.patch is already applied; leaving the solved tree unchanged" >&2
else
  echo "solve.sh: golden.patch does not apply forward, and the tree does not already contain it" >&2
  exit 1
fi
