`MathPHP\Finance` can already value a schedule — PMT, FV, PV and NPV all run forward from a known interest rate. What's missing is the way back: given a schedule and the value it ends at, what rate produced it? Add that.

`rate(float $periods, float $payment, float $present_value, float $future_value, bool $beginning = false, float $initial_guess = 0.1): float` returns the periodic interest rate at which the present value, the payments and the future value balance over the given number of periods. It is the inverse of `fv()`: hand it the future value that some rate produced and that rate must come back, for payments at the end of each period and at the start alike. Results are accurate to within `Finance::EPSILON`, and the same near-zero normalisation the rest of the class applies holds here too.

Unlike the functions already there, this one has no closed form, so the rate has to be found numerically, using the root finder the library already provides — `NumericalAnalysis\RootFinding\NewtonsMethod` — rather than a new one. The caller-supplied starting point selects where the search begins and nothing else: two callers who pass different starting points must get the same answer back.

That search is where the real work is. As it stands it keeps going until it succeeds, and on inputs that have no answer it never does — the process simply stops responding. Some inputs are like that, admitting no rate at all. So the search itself has to be made to finish and report a not-a-number result instead of running on. Two things follow, and they belong to the search rather than to its finance callers, since anything else calling it can hang just as easily:

- A search that cannot get within tolerance has to give up rather than continue, and report it as `NAN` — the value this library already uses for a result it cannot produce, and what the finance layer in front of it passes back to its own callers. That covers every input it cannot solve, whatever the reason, and it has to come back cleanly, without raising a diagnostic on the way out.
- How much searching it is willing to do must be something a caller can bound, with a sensible limit when the caller does not say.

None of this may cost the search its existing behaviour: problems it can already solve must still come back with the same roots, to the same tolerance, and its existing callers must keep working unchanged.
