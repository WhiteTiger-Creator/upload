`MathPHP\Finance` can already value a schedule — PMT, FV, PV and NPV all run forward from a known interest rate. What's missing is the way back: given a schedule and the value it ends at, what rate produced it? Add that.

`rate(float $periods, float $payment, float $present_value, float $future_value, bool $beginning = false, float $initial_guess = 0.1): float` returns the periodic interest rate at which the present value, the payments and the future value balance over the given number of periods. It is the inverse of `fv()`: hand it the future value that some rate produced and that rate must come back, for payments at the end of each period and at the start alike. Results are accurate to within `Finance::EPSILON`, and the same near-zero normalisation the rest of the class applies holds here too.

Unlike the functions already there, this one has no closed form — the rate has to be searched for numerically, and the library's own Newton's method is the search to use. The caller-supplied starting point selects where that search begins and nothing else: two callers who pass different starting points must get the same answer back.

That search is where the real work is. As it stands it iterates until it converges, and on inputs that have no answer it never does — the process simply stops responding. Plenty of inputs are like that: money in, money out and the closing balance all pointing the same way admit no rate at all. So the search itself has to be made to finish and report a not-a-number result instead of running on. Three things follow from that, and they belong to the search rather than to its finance callers, since anything else calling it can hang just as easily:

- A search that cannot get within tolerance has to give up and report `NAN` rather than continue.
- A step needs a slope to move along. Where that slope vanishes the next guess is undefined, and that has to be reported rather than divided by.
- How many steps it is willing to take should be something a caller can set, with a sensible bound when they don't.

None of this may cost the search its existing behaviour: problems it can already solve must still come back with the same roots, to the same tolerance, and its existing callers must keep working unchanged.
