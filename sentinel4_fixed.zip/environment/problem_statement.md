We've got PMT and AER in the `MathPHP\Finance` class, but the future-value and present-value side of the finance toolkit is missing. Add `Finance::fv()` and `Finance::pv()` so the class matches the `=FV()` and `=PV()` functions you'd get in spreadsheet software, plus the plumbing to keep results clean around zero.

The class exposes a constant `EPSILON = 1e-6`, the floating-point range near zero treated as insignificant. Any result these methods produce whose magnitude is smaller than `EPSILON` must be returned as exactly `0.0`, with negative zero normalized to positive `0.0`; a magnitude of `EPSILON` or greater is returned unchanged.

`fv(float $rate, int $periods, float $payment, float $present_value, bool $beginning = false): float` returns the future value of a loan or annuity under compound interest — the same quantity a spreadsheet's `=FV()` produces, and with the same sign conventions, where money paid in and money borrowed carry opposite signs. The `beginning` flag selects whether each payment falls at the start of its period rather than the end, which shifts the result accordingly. As an example, `fv(0.035/12, 5*12, 1189.97, -265000, false)` is the principal still outstanding after 5 years on a 30-year fixed $265,000 mortgage note at 3.5%, where the present value is negative (money borrowed) and the payment positive (money paid in).

`pv(float $rate, int $periods, float $payment, float $future_value, bool $beginning = false): float` returns the present value in the same style as a spreadsheet's `=PV()`, with the same sign conventions and the same `beginning`-flag handling. For example, `pv(0.035/12, 5*12, 0, -1000, false)` is the present value of a $1000 bond paid in 5 years at 3.5% compounded monthly, and `pv(0.05, 5, -70, -1000, false)` values a $1000 5-year bond paying a 7% ($70) annual coupon at a 5% discount rate.

Alongside those, the class needs the inverse side of the same toolkit — the parts a spreadsheet exposes as `=NPV()`, `=RATE()` and `=IRR()`.

`npv(float $rate, array $values): float` discounts a series of cash flows back to today, the first entry being the flow that happens immediately.

`rate(float $periods, float $payment, float $present_value, float $future_value, bool $beginning = false, float $initial_guess = 0.1): float` answers the opposite question to the ones above: given the term, the payment and the two ends of the balance, what periodic rate makes them consistent? It follows the same sign convention and the same `beginning` handling as the rest of the family.

`irr(array $values, float $initial_guess = 0.1): float` returns the rate at which a series of cash flows breaks even — the rate that drives `npv` to zero. Fewer than two cash flows have no such rate, and the result is `NAN`.

Both `rate` and `irr` take an `initial_guess` as a starting hint. It is a hint only: the answer is a property of the inputs, so a caller who passes a poor guess must still get the same rate back, to within `EPSILON`, and the rate they report is the meaningful one — a periodic rate at or below -100% is not an answer. Neither has a closed form, so both are solved numerically, and both are subject to the same near-zero normalization as everything else in the class.

Results must be accurate to within `Finance::EPSILON`. The new methods belong to the `MathPHP\Finance` class.
