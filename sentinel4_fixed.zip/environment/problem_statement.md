We've got PMT and AER in the `MathPHP\Finance` class, but the future-value and present-value side of the finance toolkit is missing, and so is everything that runs the other way — given a cash-flow schedule, what rate does it imply? Fill both in.

The class exposes a constant `EPSILON = 1e-6`, the floating-point range near zero treated as insignificant. Any result these methods produce whose magnitude is smaller than `EPSILON` must be returned as exactly `0.0`, with negative zero normalized to positive `0.0`; a magnitude of `EPSILON` or greater is returned unchanged.

## The value functions

`fv(float $rate, int $periods, float $payment, float $present_value, bool $beginning = false): float` returns the future value of a loan or annuity under compound interest — the same quantity a spreadsheet's `=FV()` produces, and with the same sign conventions, where money paid in and money borrowed carry opposite signs. The `beginning` flag selects whether each payment falls at the start of its period rather than the end, which shifts the result accordingly. As an example, `fv(0.035/12, 5*12, 1189.97, -265000, false)` is the principal still outstanding after 5 years on a 30-year fixed $265,000 mortgage note at 3.5%, where the present value is negative (money borrowed) and the payment positive (money paid in).

`pv(float $rate, int $periods, float $payment, float $future_value, bool $beginning = false): float` returns the present value in the same style as a spreadsheet's `=PV()`, with the same sign conventions and the same `beginning`-flag handling. For example, `pv(0.035/12, 5*12, 0, -1000, false)` is the present value of a $1000 bond paid in 5 years at 3.5% compounded monthly, and `pv(0.05, 5, -70, -1000, false)` values a $1000 5-year bond paying a 7% ($70) annual coupon at a 5% discount rate.

`npv(float $rate, array $values): float` is the net present value of a series of periodic, equally spaced cash flows. The first entry sits at time zero and is therefore undiscounted; each later entry is discounted one period more than the one before it.

## The rate functions

These are the inverses, and unlike the ones above they have no closed form — the answer has to be searched for numerically.

`rate(float $periods, float $payment, float $present_value, float $future_value, bool $beginning = false, float $initial_guess = 0.1): float` returns the periodic interest rate at which the present value, the payments and the future value balance over the given number of periods. It must invert `fv()`: hand it the future value that some rate produces and that same rate must come back, for end-of-period and beginning-of-period payments alike.

`irr(array $values, float $initial_guess = 0.1): float` returns the internal rate of return of a series of cash flows — the discount rate at which their net present value is zero. Discounting the flows at whatever rate it reports must leave a net present value of zero.

Both take a caller-supplied starting point for the search. That argument selects where the search begins and nothing else: two callers who pass different starting points must get the same answer back.

Three behaviours matter as much as the arithmetic:

- **No answer is a valid answer.** Plenty of inputs admit no rate at all — cash flows that never change sign, or a present value, payment and future value that all point the same way. These must return `NAN`.
- **Every call has to finish.** A search that cannot home in on an answer must give up and report `NAN` rather than run forever. This holds for whatever the search is asked to solve, not only for the finance functions calling it.
- **Zero is a real rate.** When the flows already balance with no interest at all — ten payments of 100 against 1000 borrowed — the rate is `0.0`, and it must be returned as such rather than reported as no answer.

Results must be accurate to within `Finance::EPSILON`. The new methods belong to the `MathPHP\Finance` class, and existing behaviour elsewhere in the library must keep working.
