We've got PMT and AER in the `MathPHP\Finance` class, but the future-value and present-value side of the finance toolkit is missing. Fill it in.

Give the class a constant `EPSILON = 1e-6`, the floating-point range near zero treated as insignificant. Any result these methods produce whose magnitude is smaller than `EPSILON` must be returned as exactly `0.0`, with negative zero normalized to positive `0.0`; a magnitude of `EPSILON` or greater is returned unchanged.

`fv(float $rate, int $periods, float $payment, float $present_value, bool $beginning = false): float` returns the future value of a loan or annuity under compound interest — the same quantity a spreadsheet's `=FV()` produces, and with the same sign conventions, where money paid in and money borrowed carry opposite signs. The `beginning` flag selects whether each payment falls at the start of its period rather than the end, which shifts the result accordingly. As an example, `fv(0.035/12, 5*12, 1189.97, -265000, false)` is the principal still outstanding after 5 years on a 30-year fixed $265,000 mortgage note at 3.5%, where the present value is negative (money borrowed) and the payment positive (money paid in).

`pv(float $rate, int $periods, float $payment, float $future_value, bool $beginning = false): float` returns the present value in the same style as a spreadsheet's `=PV()`, with the same sign conventions and the same `beginning`-flag handling. For example, `pv(0.035/12, 5*12, 0, -1000, false)` is the present value of a $1000 bond paid in 5 years at 3.5% compounded monthly, and `pv(0.05, 5, -70, -1000, false)` values a $1000 5-year bond paying a 7% ($70) annual coupon at a 5% discount rate.

A rate of zero is a legitimate input to both: compound interest degenerates there, and the value still has to come back correct rather than as a division by zero. Payments falling at the start of the period behave the same way, and when the flag is left off, payments fall at the end of the period.

Results must be accurate to within `Finance::EPSILON`. The new methods belong to the `MathPHP\Finance` class, and existing behaviour elsewhere in the library must keep working.
