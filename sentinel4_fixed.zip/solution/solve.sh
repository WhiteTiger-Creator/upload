#!/usr/bin/env bash
set -e
cd /app

# Apply the reference solution forward only. A reverse fallback would strip the
# solution back out of the source while still exiting 0, so a tree this script
# cannot patch forward is a hard failure.
if git apply -p1 --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --whitespace=nowarn /solution/golden.patch
elif git apply -p1 --3way --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --3way --whitespace=nowarn /solution/golden.patch
else
  echo "solve.sh: golden.patch does not apply forward to this tree" >&2
  exit 1
fi
